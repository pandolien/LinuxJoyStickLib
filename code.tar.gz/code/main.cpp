#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hJoystick.h"


typedef struct {
	float v;
	float w;
}Vt;
void Control_Joystick(void*Dt,void *joystick){
	Vt *vt = (Vt*)Dt;
	hJoystick *joy = (hJoystick*)joystick;
	if(joy->Error){
		printf("allClear\n");	
		memset(vt,0,sizeof(Vt));
	}
}
int main(int argc,char **argv){
	hJoystick joy;
	Vt vt;
	memset(&vt,0,sizeof(Vt));
	joy.Function = Control_Joystick;
	joy.Data = &vt;
	joy.Init("/dev/input/js4");// /dev(USB Serial Data File)/input(input Directory)/js0(JoyStick Number)
	joy.Start();//ThreadStart//
	while(1){
		if(joy.Error)break;
		sleep(1);
	}
	joy.Close();//Thread & joystick Close
	return 0;
}
