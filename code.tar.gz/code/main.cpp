#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hJoystick.h"


typedef struct {
	float v;
	float w;
}Vt;
void Control_Joystick(void*Dt,JoyStickData jsdt){
	Vt *vt = (Vt*)Dt;
	printf("joystick\n\tL = %6d\t,%6d\n\tR = %6d\t,%6d\n",jsdt.L.x,jsdt.L.y,jsdt.R.x,jsdt.R.y);
}
int main(int argc,char **argv){
	hJoystick joy;
	Vt vt;
	memset(&vt,0,sizeof(Vt));
	joy.Function = Control_Joystick;
	joy.Data = &vt;
	joy.Init("/dev/input/js0");// /dev(USB Serial Data File)/input(input Directory)/js0(JoyStick Number)
	joy.Start();//ThreadStart//
	sleep(1000);//while//
	joy.Close();//Thread & joystick Close
	return 0;
}
