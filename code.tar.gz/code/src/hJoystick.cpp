#include "hJoystick.h"

hJoystick::hJoystick(){
	Initialzation();
}
hJoystick::~hJoystick(){
	Close();
}
void hJoystick::Initialzation(){
	Function = NULL;
	Data = NULL;
	FD_ZERO(&Jfd);
	ThreadPlage = true;
	fd = -1;
	Error = false;
	memset(&joystickdata,0,sizeof(JoyStickData));
}
void hJoystick::Init(const char *Name){
	fd = open(Name,O_RDONLY|O_NONBLOCK);
	if(fd == -1)return;
	FD_SET(fd,&Jfd);
	printf("joyStickOpen\n");
}
void hJoystick::Close(){
	Stop();
	if(fd == -1)return;
	close(fd);
	fd = -1;
	printf("joyStickClose\n");
	memset(&joystickdata,0,sizeof(JoyStickData));
	Function(Data,joystickdata);
	Function = NULL;
	Data = NULL;
}
void hJoystick::Start(){
	if(ThreadPlage){
		ThreadPlage = false;
		pthread_create(&trd,NULL,hJoystick::run_,this);
	}
}
void hJoystick::Stop(){
	if(ThreadPlage)return;
	ThreadPlage = true;
	usleep(100000);
	pthread_join(trd,NULL);
}
void* hJoystick::run_(void *This){
	hJoystick *pthis = (hJoystick*)This;
	printf("hello\n");
	while(1){
		if(pthis->run()) break;
		usleep(10000);
		//printf("Recv\n");
	}
	return NULL;
}
bool hJoystick::run(){
	struct timeval timeout;
	timeout.tv_sec = 0;
	timeout.tv_usec = 5000;
	fd_set Tep;
	Tep = Jfd;
	if(fd == -1) {
		Error = true;
		printf("Not FD\n");
		return true;
	}
	int Ready = select(fd+1,&Tep,NULL,NULL,&timeout);

	if(FD_ISSET(fd,&Tep)){
		if(read(fd,&evt,sizeof(evt))){
			//printf("%d\n",evt.type);
			if(evt.type == JS_EVENT_BUTTON){
				switch(evt.number){
				case 0:
					if(evt.value == 0)	joystickdata.button.A = false;
					else			joystickdata.button.A = true;
					break;
				case 1:
					if(evt.value == 0)	joystickdata.button.B = false;
					else			joystickdata.button.B = true;
					break;
				case 3:
					if(evt.value == 0)	joystickdata.button.X = false;
					else			joystickdata.button.X = true;
					break;
				case 4:
					if(evt.value == 0)	joystickdata.button.Y = false;
					else			joystickdata.button.Y = true;
					break;
				case 6:
					if(evt.value == 0)	joystickdata.button.L1 = false;
					else			joystickdata.button.L1 = true;
					break;
				case 7:
					if(evt.value == 0)	joystickdata.button.R1 = false;
					else			joystickdata.button.R1 = true;
					break;
				case 11:
					if(evt.value == 0)	joystickdata.button.Menu = false;
					else			joystickdata.button.Menu = true;
					break;
				
				}
				//printf("Button Event code %d,\t value %d\n", evt.number,evt.value);
			}
			else if(evt.type == JS_EVENT_AXIS){
				switch(evt.number){				
				case 0:
					joystickdata.L.x = evt.value;
					break;
				case 1:
					joystickdata.L.y = evt.value;
					break;
				case 2:
					joystickdata.R.x = evt.value;
					break;
				case 3:
					joystickdata.R.y =evt.value;
					break;
				case 4:
					joystickdata.button.R2 = evt.value;
					break;
				case 5:
					joystickdata.button.L2 = evt.value;
					break;
				case 7:
					if(evt.value == 0)	{
						joystickdata.button.MF = false;
						joystickdata.button.MB = false;
					}
					else if(evt.value > 0)	{
						joystickdata.button.MF = false;
						joystickdata.button.MB = true;
					}
					else if(evt.value < 0)	{
						joystickdata.button.MF = true;
						joystickdata.button.MB = false;
					}
					break;
				case 6:
					if(evt.value == 0)	{
						joystickdata.button.ML = false;
						joystickdata.button.MR = false;
					}
					else if(evt.value > 0)	{
						joystickdata.button.ML = false;
						joystickdata.button.MR = true;
					}
					else if(evt.value < 0)	{
						joystickdata.button.ML = true;
						joystickdata.button.MR = false;
					}
					break;
				
				}
				//printf("Axis Event code %d,\t value %d\n", evt.number,evt.value);
			}
			if(Function != NULL)Function(Data,joystickdata);
		}	
	}
	return ThreadPlage;
}
