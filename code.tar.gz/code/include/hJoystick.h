#ifndef __HJOYSTICK_H__
#define __HJOYSTICK_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <linux/joystick.h>
#include <fcntl.h>
#include <sys/select.h>

#include <pthread.h>
typedef struct {
	short x,y;
}Axis;
typedef struct {
	bool L,R;
	bool L1,R1;
	short L2,R2;
	bool A,B,Y,X;
	bool Menu;
	bool ML,MR,MF,MB;
}Button;
typedef struct{
	Axis L,R;
	Button button;
}JoyStickData;
class hJoystick{
public:
	hJoystick();
	~hJoystick();
public:
	struct js_event evt;
	JoyStickData joystickdata;
	int fd;
	fd_set Jfd;
	bool ThreadPlage;
	pthread_t trd;
	bool Error;
public:
	void (*Function)(void *,JoyStickData);
	void *Data;
public:
	void Initialzation();
	void Init(const char*);
	void Close();
	void Start();
	void Stop();
	static void* run_(void*);
	bool run();
	
};
#endif
